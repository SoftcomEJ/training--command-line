# Hello World

> A simple "Hello, World!" in C language.

---

## Intructions

### Build
Compile the source code with:

```$ make build```

### Running
Run the compiled program with:

```$ make run"

### Clean
Remove any executable with:

```$ make clean```

---

## Contributors

* Max Naegeler Roecker
* João Luiz Ramalheira de Almeida

---

## License

MIT License. See `LICENSE` file.
