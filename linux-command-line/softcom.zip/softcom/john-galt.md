
Não permita que o herói que habita em tua alma 
morra em solitária frustação pela vida que você 
merecia, mas que não pode alcançar. Analise seu 
caminho e a natureza da sua luta.

O mundo que você anseia pode ser conquistado. 
Existe, é real, é possível, é seu.

— John Galt, A Revolta de Atlas.

